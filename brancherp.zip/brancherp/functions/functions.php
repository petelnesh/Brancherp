
<?php

include ("includes/connect.php");
function insertOrganisation(){

  if(isset($_POST['insert_post'])){
 
 //getting the text data from fields

$product_price=$_POST['product_price'];
$product_desc=$_POST['product_desc'];
$product_keywords=$_POST['product_keywords'];

move_uploaded_file($product_image_tmp, "images/$product_image");
$insert_product="insert into products (product_price,product_image,product_desc,product_keywords)
     values('$product_price','$product_image','$product_desc','$product_keywords')";


      $insert_pro=mysqli_query($con,$insert_product);

      if($insert_pro){
        echo "<script>alert('Product has been Inserted!')</script>";
        echo "<script>window.open('insert_product.php','_self')</script>";
      }
   
  }
}
?>