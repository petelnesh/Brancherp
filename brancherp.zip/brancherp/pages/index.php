<?php

include ("connect.php");
include ("functions.php");
session_start(); // Session starts here.
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ERP MAIN</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">
<style type="text/css">
    
</style>
    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
.navbar-default {
     background-color:transparent;
    border-color: #e7e7e7;
}
.form-group.required .control-label1:after {
  content:"nssf*";
  color:red;
}
.form-group.required .control-label2:after {
  content:"nhif*";
  color:red;
}
.wizard {
        margin: 20px auto;
        background: #fff;
    }
    
    .wizard .nav-tabs {
        position: relative;
        margin: 40px auto;
        margin-bottom: 0;
        border-bottom-color: #e0e0e0;
    }
    
    .wizard > div.wizard-inner {
        position: relative;
    }
    
    .connecting-line {
        height: 2px;
        background: #e0e0e0;
        position: absolute;
        width: 70%;
        margin: 0 auto;
        left: 0;
        right: 0;
        top: 50%;
    }
    
    .wizard .nav-tabs > li.active > a,
    .wizard .nav-tabs > li.active > a:hover,
    .wizard .nav-tabs > li.active > a:focus {
        color: #555555;
        cursor: default;
        border: 0;
        border-bottom-color: transparent;
    }
    
    span.round-tab {
        width: 70px;
        height: 70px;
        line-height: 70px;
        display: inline-block;
        border-radius: 100px;
        background: #fff;
        border: 2px solid #e0e0e0;
        position: absolute;
        left: 0;
        text-align: center;
        font-size: 25px;
    }
    
    span.round-tab i {
        color: #555555;
    }
    
    .wizard li.active span.round-tab {
        background: #fff;
        border: 2px solid #5bc0de;
    }
    
    .wizard li.active span.round-tab i {
        color: #5bc0de;
    }
    
    span.round-tab:hover {
        color: #333;
        border: 2px solid #333;
    }
    
    .wizard .nav-tabs > li {
        width: 33%;
    }
    
    .wizard li:after {
        content: " ";
        position: absolute;
        left: 46%;
        opacity: 0;
        margin: 0 auto;
        bottom: 0px;
        border: 5px solid transparent;
        border-bottom-color: #5bc0de;
        transition: 0.1s ease-in-out;
    }
    
    .wizard li.active:after {
        content: " ";
        position: absolute;
        left: 46%;
        opacity: 1;
        margin: 0 auto;
        bottom: 0px;
        border: 10px solid transparent;
        border-bottom-color: #5bc0de;
    }
    
    .wizard .nav-tabs > li a {
        width: 70px;
        height: 70px;
        margin: 20px auto;
        border-radius: 100%;
        padding: 0;
    }
    
    .wizard .nav-tabs > li a:hover {
        background: transparent;
    }
    
    .wizard .tab-pane {
        position: relative;
        padding-top: 50px;
    }
    
    .wizard h3 {
        margin-top: 0;
    }
    
    .step1 .row {
        margin-bottom: 10px;
    }
    
    .step_21 {
        border: 1px solid #eee;
        border-radius: 5px;
        padding: 10px;
    }
    
    .step33 {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding-left: 10px;
        margin-bottom: 10px;
    }
    
    .dropselectsec {
        width: 68%;
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        outline: none;
        font-weight: normal;
    }
    
    .dropselectsec1 {
        width: 74%;
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        outline: none;
        font-weight: normal;
    }
    
    .mar_ned {
        margin-bottom: 10px;
    }
    
    .wdth {
        width: 25%;
    }
    
    .birthdrop {
        padding: 6px 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        color: #333;
        margin-left: 10px;
        width: 16%;
        outline: 0;
        font-weight: normal;
    }
    /* according menu */
    
    #accordion-container {
        font-size: 13px
    }
    
    .accordion-header {
        font-size: 13px;
        background: #ebebeb;
        margin: 5px 0 0;
        padding: 7px 20px;
        cursor: pointer;
        color: #fff;
        font-weight: 400;
        -moz-border-radius: 5px;
        -webkit-border-radius: 5px;
        border-radius: 5px;
    }
    
    .unselect_img {
        width: 18px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    
    .active-header {
        -moz-border-radius: 5px 5px 0 0;
        -webkit-border-radius: 5px 5px 0 0;
        border-radius: 5px 5px 0 0;
        background: #F53B27;
    }
    
    .active-header:after {
        content: "\f068";
        font-family: 'FontAwesome';
        float: right;
        margin: 5px;
        font-weight: 400
    }
    
    .inactive-header {
        background: #333;
    }
    
    .inactive-header:after {
        content: "\f067";
        font-family: 'FontAwesome';
        float: right;
        margin: 4px 5px;
        font-weight: 400
    }
    
    .accordion-content {
        display: none;
        padding: 20px;
        background: #fff;
        border: 1px solid #ccc;
        border-top: 0;
        -moz-border-radius: 0 0 5px 5px;
        -webkit-border-radius: 0 0 5px 5px;
        border-radius: 0 0 5px 5px
    }
    
    .accordion-content a {
        text-decoration: none;
        color: #333;
    }
    
    .accordion-content td {
        border-bottom: 1px solid #dcdcdc;
    }
    
    @media( max-width: 585px) {
        .wizard {
            width: 90%;
            height: auto !important;
        }
        span.round-tab {
            font-size: 16px;
            width: 50px;
            height: 50px;
            line-height: 50px;
        }
        .wizard .nav-tabs > li a {
            width: 50px;
            height: 50px;
            line-height: 50px;
        }
        .wizard li.active:after {
            content: " ";
            position: absolute;
            left: 35%;
        }
    }
    
    .box {
        width: 40%;
        margin: 0 auto;
        background: rgba(255, 255, 255, 0.2);
        padding: 35px;
        border: 2px solid #fff;
        border-radius: 20px/50px;
        background-clip: padding-box;
        text-align: center;
    }
    
    .overlay {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: #404040;
        transition: opacity 500ms;
        visibility: hidden;
        opacity: 0;
    }
    
    .overlay:target {
        visibility: visible;
        opacity: 1;
    }
    
    .popup {
        margin: 70px auto;
        padding: 20px;
        background: #fff;
        border-radius: 5px;
        width: 80%;
        position: relative;
        transition: all 5s ease-in-out;
    }
    
    .popup h2 {
        margin-top: 0;
        color: #333;
        font-family: Tahoma, Arial, sans-serif;
    }
    
    .popup .close {
        position: absolute;
        top: 20px;
        right: 30px;
        transition: all 200ms;
        font-size: 30px;
        font-weight: bold;
        text-decoration: none;
        color: #333;
    }
    
    .popup .close:hover {
        color: #06D85F;
    }
    
    .popup .content {
        max-height: 30%;
        overflow: auto;
    }
    
    @media screen and (max-width: 700px) {
        .box {
            width: 70%;
        }
        .popup {
            width: 70%;
        }
    }
    
    .a9 {
        margin-top: 300px;
        margin-left: 300px;
        float: left;
    }
    
    #ninja-slider .caption {
        position: absolute;
        top: 100%;
    }
    
    #ninja-slider .slider-inner {
        padding-bottom: 100px!important;
    }
    
    #ninja-slider li {
        margin-bottom: 100px!important;
    }
    
    #ninja-slider ul {
        overflow: visible!important;
    }
    
    #ninja-slider li {
        /*overflow:hidden;*/
    }
</style>
</head>


<body>

     <?php
 if (!empty($_SESSION['error'])) {
 echo $_SESSION['error'];
 unset($_SESSION['error']);
 }
 ?>

    <div id="wrapper">

         <?php include_once('partial.php');?>

        <div id="page-wrapper">
            <div class="row">
                <section>
                    <div class="wizard">
                        <div class="wizard-inner">
                            <div class="connecting-line"></div>
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-folder-open"></i>
                            </span>
                                    </a>
                                </li>
                                <li role="presentation" class="disabled">
                                    <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-pencil"></i>
                            </span>
                                    </a>
                                </li>
                                <li role="presentation" class="disabled">
                                    <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                        <span class="round-tab">
                                <i class="glyphicon glyphicon-picture"></i>
                            </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <form role="form">
                            <div class="tab-content">
                                <div class="tab-pane active" role="tabpanel" id="step1">
                                     
                                    <div class="step1">
                                        <!--first goes here-->
                                        <div class="panel panel-default">
      <div class="panel-heading"><h4 style="color: #1a75ff;">Step one-Basic Branch Details</h4></div>
      <div class="panel-body">

        <form>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Branch Code:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch code">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Debtor number:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter deptor number">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Branch Name</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter branch name">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Branch Address 1</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Address 1">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Branch Address 2</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch 2">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Branch Address 3</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Address 3">
  </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Branch Address 4</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Address 4">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Branch Address 5</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Branch Address 5">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Branch Address 6</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Address 6">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Latitude</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Latitude">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Longitude</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Longitude">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Estimated Delivery Day</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Estimated Delivery Day">
  </div>
                </div>
            </div>
            <ul class="list-inline pull-right">


                                        <li>
                                            <button type="button" class="btn btn-primary next-step">Save and continue</button>
                                        </li>
                                    </ul>
      </div>
        </form>
           
    </div>

                                        
                                    </div>
                                   
                                </div>
                                <div class="tab-pane" role="tabpanel" id="step2">
                                    <div class="step-22">
                                        <div id="form-step-1" role="form" data-toggle="validator">
                                                            <div class="panel panel-default">
      <div class="panel-heading"><h4 style="color: #1a75ff;">Step Two-Branch Details</h4></div>
      <div class="panel-body">

        <form>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Area:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Area">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Salesman:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Salesman">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Forward Date:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Forward Date">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Phone Number:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Phone Number">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Fax Number:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Fax Number">
  </div>
  
                </div>
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Contact Name:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Contact Name">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Email:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Email">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Default Location:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Default Location">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Tax Group Id:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Tax Group Id">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Default Shivia:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Default Shivia">
  </div>
  
                </div>
            </div>
            <ul class="list-inline pull-right">
                                        <li>
                                            <button type="button" class="btn btn-default prev-step">Previous</button>
                                        </li>
                                        <li>
                                            <button type="button" class="btn btn-primary next-step">Save and continue</button>
                                        </li>
                                    </ul>
      </div>
        </form>
           
    </div>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="tab-pane" role="tabpanel" id="step3">
                                    <div class="step3">
                                      
                                          <div class="panel panel-default">
      <div class="panel-heading"><h4 style="color: #1a75ff;">Step Three-Branch Details</h4></div>
      <div class="panel-body">

        <form>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Deliver Blind:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Deliver Blind">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Disable Transaction:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Disable Transaction">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Branch Postal Address 1:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Postal Address 1">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Branch Postal Address 2:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Branch Postal Address 2">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Branch Postal Address 3:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Postal Address 3">
  </div>
  
                </div>
                <div class="col-md-6">
                    <div class="form-group">
    <label for="formGroupExampleInput">Branch Postal Address 4:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Postal Address 4">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Branch Postal Address 5:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Branch Postal Address 5">
  </div>
                   <div class="form-group">
    <label for="formGroupExampleInput">Branch Postal Address 6:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Branch Postal Address 6">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Special Instruction:</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Enter Special Instruction">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput">Customer Branch Code:</label>
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Customer Branch Code">
  </div>
  
                </div>
            </div>
            <ul class="list-inline pull-right" style="margin-top: 50px;">
                                        <li>
                                            <button type="button" class="btn btn-default prev-step">Previous</button>
                                        </li>
                                        <li>
                                            <button type="button" class="btn btn-primary btn-info-full next-step">Finish</button>
                                        </li>
                                    </ul>
      </div>
        </form>
           
    </div>  
                                   
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
    </div>

    </div>
    <!-- /#wrapper -->
<?php
insertOrg();
updateOrg();
?>
    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
<?php

 if(isset($_POST['dublicate'])){
/********************* START CONFIGURATION *********************/
$DB_SRC_HOST='localhost';
$DB_SRC_USER='root';
$DB_SRC_PASS='';
$DB_SRC_NAME='grandways_hr';
$DB_DST_HOST='localhost';
$DB_DST_USER='root';
$DB_DST_PASS='';
$DB_DST_NAME='orangehrm';

/*********************** GRAB OLD SCHEMA ***********************/
$db1 = new mysqli ($DB_SRC_HOST,$DB_SRC_USER,$DB_SRC_PASS) or die($db1->error);
mysqli_select_db($db1,$DB_SRC_NAME) or die($db1->error);
$result = mysqli_query($db1,"SHOW TABLES;") or die($db1->error);
$buf="set foreign_key_checks = 0;\n";
$constraints='';
while($row = mysqli_fetch_array($result))
{
    $result2 = mysqli_query($db1,"SHOW CREATE TABLE ".$row[0].";") or die($db1->error);
    $res = mysqli_fetch_array($result2);
    if(preg_match("/[ ]*CONSTRAINT[ ]+.*\n/",$res[1],$matches))
    {
        $res[1] = preg_replace("/,\n[ ]*CONSTRAINT[ ]+.*\n/","\n",$res[1]);
        $constraints.="ALTER TABLE ".$row[0]." ADD ".trim($matches[0]).";\n";
    }
    $buf.=$res[1].";\n";
}
$buf.=$constraints;
$buf.="set foreign_key_checks = 1";

/**************** CREATE NEW DB WITH OLD SCHEMA ****************/
$db2 = new mysqli($DB_DST_HOST,$DB_DST_USER,$DB_DST_PASS) or die($db2->error);
$sql = 'CREATE DATABASE '.$DB_DST_NAME;
if(!mysqli_query($db2,$sql)) die($db2->error);
mysqli_select_db($db2,$DB_DST_NAME) or die($db2->error);
$queries = explode(';',$buf);
foreach($queries as $query)
{
    if(!mysqli_query($db2,$query)) die($db2->error);
}

  }

?>
