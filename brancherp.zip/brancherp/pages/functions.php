<?php
$con =mysqli_connect("localhost","root","","erp");

if(mysqli_connect_errno()){
    echo "The Connection was not established: " .mysql_connect_error();
}


function getPro(){

 global $con;
    $get_prod="select * from ohrm_organization_gen_info order by RAND() LIMIT 0,15";

    $run_prod=mysqli_query($con,$get_prod);

    while($row_prod=mysqli_fetch_array($run_prod)){


        $name=$row_prod['name'];
       
        $tax_id=$row_prod['tax_id'];
        $registration_number=$row_prod['registration_number'];
         $phone=$row_prod['phone'];
       
        $fax=$row_prod['fax'];
        $email=$row_prod['email'];
         $country=$row_prod['country'];
       
        $province=$row_prod['province'];
        $city=$row_prod['city'];
         $zip_code=$row_prod['zip_code'];
       
        $street1=$row_prod['street1'];
        $street2=$row_prod['street2'];
         $note=$row_prod['note'];

        echo "
          <tbody>
          <tr class='success'>
          <td>$name</td>
                                            <td>$tax_id </td>
                                            <td> $registration_number </td>
                                            <td>  $street2 </td>
                                            <td>  $fax </td>
                                            <td>  $email </td>
                                            <td>  $country </td>
                                            <td>  $province </td>
                                            <td>  $city </td>
                                            <td>  $zip_code </td>
                                            <td>  $street1 </td>
                                            
                                            <td>  $note </td>
          </tr>
          
          </tbody>

        ";
    
}
}
function insertOrg(){


	if(isset($_POST['insert_org'])){
 
 //getting the text data from fields
		global $con;

$name=$_POST['name'];
$taxid=$_POST['taxid'];
$regno=$_POST['regno'];
$phone=$_POST['phone'];
$fax=$_POST['fax'];
$email=$_POST['email'];
$country=$_POST['country'];
$province=$_POST['province'];
$city=$_POST['city'];
$zip=$_POST['zip'];
$strone=$_POST['strone'];
$strtwo=$_POST['strtwo'];
$note=$_POST['note'];



 $insert_org="INSERT INTO ohrm_organization_gen_info (name,tax_id,registration_number,phone,fax,email,country,province,city,zip_code,street1,street2,note)
     VALUES('$name','$taxid','$regno','$phone','$fax','$email','$country','$province','$city','$zip','$strone','$strtwo','$note')";
      
      echo  $insert_org;

      $insert_pro=mysqli_query($con,$insert_org);

      if($insert_pro){
        echo "<script>alert('Organisation has been Inserted!')</script>";
        echo "<script>window.open('index.php','_self')</script>";

      }else{
         echo "<script>alert('Organisation failed !')</script>";
      }
   
  }
}
function updateOrg(){

	if(isset($_POST['update_org'])){
 
 //getting the text data from fields
		global $con;

$name=$_POST['name'];
$taxid=$_POST['taxid'];
$regno=$_POST['regno'];
$phone=$_POST['phone'];
$fax=$_POST['fax'];
$email=$_POST['email'];
$country=$_POST['country'];
$province=$_POST['province'];
$city=$_POST['city'];
$zip=$_POST['zip'];
$strone=$_POST['strone'];
$strtwo=$_POST['strtwo'];
$note=$_POST['note'];

 $update_org="UPDATE ohrm_organization_gen_info SET name='$name',tax_id='$taxid',registration_number='$regno',phone='$phone',fax='$fax',email='$email',country='$country',province='$province',city='$city',zip_code='$zip',street1='$strone',street2='$strtwo',note='$note' where name=$name";
      
      $update_pro=mysqli_query($con,$update_org);

      if($update_pro){
        echo "<script>alert('Organisation has been Inserted!')</script>";
        echo "<script>window.open('index.php','_self')</script>";

      }else{
         echo "<script>alert('Organisation failed !')</script>";
      }
   
  }

}
?>